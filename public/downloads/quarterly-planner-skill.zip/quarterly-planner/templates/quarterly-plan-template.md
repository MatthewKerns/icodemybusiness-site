# Quarterly Plan — {{QUARTER}} {{YEAR}}  ({{START_DATE}} → {{END_DATE}})

> EOS quarterly pulse. Fill from reviewed context — leave a field blank rather
> than invent it. Re-run the `quarterly-planner` skill next quarter; it reads
> this file back in to close the loop.

## 1-Year Plan (from the V/TO)

- **Future date:** {{ONE_YEAR_DATE}}
- **Revenue / profit / measurable target:** {{ONE_YEAR_TARGETS}}
- **Goals for the year (3–7):**
  1. {{YEAR_GOAL_1}}
  2. {{YEAR_GOAL_2}}
  3. {{YEAR_GOAL_3}}

## Last Quarter Review

| Rock | Owner | Done? | Note / why |
|------|-------|-------|------------|
| {{PREV_ROCK_1}} | | ☐ | |
| {{PREV_ROCK_2}} | | ☐ | |

**Completion:** {{PREV_COMPLETION}} %  ·  **Pattern to carry forward:** {{PREV_LESSON}}

## This Quarter's Rocks (3–7)

Each Rock: specific, measurable, owned, due by {{END_DATE}}, and laddered to a 1-year goal.

| # | Rock (done = …) | Owner | Due | Ladders to |
|---|-----------------|-------|-----|------------|
| 1 | {{ROCK_1}} | | {{END_DATE}} | {{ROCK_1_LADDER}} |
| 2 | {{ROCK_2}} | | {{END_DATE}} | {{ROCK_2_LADDER}} |
| 3 | {{ROCK_3}} | | {{END_DATE}} | {{ROCK_3_LADDER}} |

## Scorecard (5–15 weekly measurables)

Leading indicators — the activity that drives the Rocks. Review every week.

| Measurable | Owner | Weekly goal |
|------------|-------|-------------|
| {{METRIC_1}} | | {{GOAL_1}} |
| {{METRIC_2}} | | {{GOAL_2}} |
| {{METRIC_3}} | | {{GOAL_3}} |

## Issues List (parked — solve via IDS in the weekly L10)

Everything that didn't make the Rocks cut: open decisions, problems, dropped threads.

1. {{ISSUE_1}}
2. {{ISSUE_2}}
3. {{ISSUE_3}}

## Weekly Level 10 Meeting agenda (same time, every week)

| Segment | Min | Purpose |
|---------|-----|---------|
| Segue | 5 | Personal + business good news |
| Scorecard | 5 | Review measurables; off-track → Issues |
| Rock review | 5 | On-track / off-track each Rock; off → Issues |
| Customer/Employee headlines | 5 | Notables; drop into Issues if needed |
| To-Do review | 5 | Last week's 7-day commitments, done? |
| **IDS** | 60 | Identify · Discuss · Solve the priority Issues |
| Conclude | 5 | Recap To-Dos, cascade messages, rate 1–10 |

**Next L10:** {{NEXT_L10_DATE}}
